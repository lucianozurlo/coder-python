# Se importan las clases Persona y Cliente para que sean accesibles cuando alguien use tu paquete (no relevante para el estado actual del programa). 
# El archivo __init__.py podría quedar vacío o no existir. Se mantiene por convención de Python.

from ecommerce.persona import Persona
from ecommerce.cliente import Cliente