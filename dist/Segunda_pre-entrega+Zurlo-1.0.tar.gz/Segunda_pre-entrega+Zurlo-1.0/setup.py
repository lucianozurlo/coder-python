from setuptools import setup

setup(
    name='Segunda_pre-entrega+Zurlo',
    version='1.0',
    description='Segunda Preentrega de Luciano Zurlo (incluye Primera Preentrega)',
    author='Luciano Zurlo',
    author_email='lucianozuri@gmail.com',
    packages=['ecommerce','primera_pre-entrega']
)